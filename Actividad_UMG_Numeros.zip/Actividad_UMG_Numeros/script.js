function esPrimo(numero) {
	if (numero <= 1) {
		return false;
	}

	for (var i = 2; i <= Math.sqrt(numero); i++) {
		if (numero % i == 0) {
			return false;
		}
	}

	return true;
}

function obtenerNumerosPrimos(numero) {
	var numerosPrimos = [];

	for (var i = 2; i <= numero; i++) {
		if (esPrimo(i)) {
			numerosPrimos.push(i);
		}
	}

	return numerosPrimos;
}

function sumarNumeros(numeros) {
	var sumatoria = 0;

	for (var i = 0; i < numeros.length; i++) {
		sumatoria += numeros[i];
	}

	return sumatoria;
}
function procesarDatos() {
	var numero = document.getElementById("numero").value;
	var nombre = document.getElementById("nombre").value;
	var numerosPrimos = obtenerNumerosPrimos(numero);
	var sumatoria = sumarNumeros(numerosPrimos);
	var fecha = new Date().toLocaleString();

	var fila = document.createElement("tr");
	var columnaNombre = document.createElement("td");
	columnaNombre.textContent = nombre;
	var columnaNumero = document.createElement("td");
	columnaNumero.textContent = numero;
	var columnaPrimos = document.createElement("td");
	columnaPrimos.textContent = numerosPrimos.join(", ");
	var columnaSumatoria = document.createElement("td");
	columnaSumatoria.textContent = sumatoria;
	var columnaFecha = document.createElement("td");
	var textoFecha = document.createTextNode(fecha);
	columnaFecha.appendChild(textoFecha);

	fila.appendChild(columnaNombre);
	fila.appendChild(columnaNumero);
	fila.appendChild(columnaPrimos);
	fila.appendChild(columnaSumatoria);
	fila.appendChild(columnaFecha);

	var historial = document.getElementById("historial");
	historial.insertBefore(fila, historial.firstChild);

	var datosHistoricos = JSON.parse(localStorage.getItem(nombre));
	if (!datosHistoricos) {
		datosHistoricos = [];
	}
	var nuevoIntento = {
		numero: numero,
		numerosPrimos: numerosPrimos,
		sumatoria: sumatoria,
		fecha: fecha
	};
	datosHistoricos.push(nuevoIntento);
	localStorage.setItem(nombre, JSON.stringify(datosHistoricos));

	document.getElementById("numero").value = "";
	document.getElementById("nombre").value = "";
}
